<?php
$con = mysqli_connect('localhost','root','','box1');